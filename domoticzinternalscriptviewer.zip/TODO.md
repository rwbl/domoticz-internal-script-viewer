### TODO Domoticz Internal Script Viewer
Status:20190517

NEW: Create UNIX version
