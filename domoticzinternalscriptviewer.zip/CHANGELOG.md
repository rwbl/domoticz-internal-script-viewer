### v1.02 (Build 20190417)

* UPD: Compiled with Lazarus v2.0.2

### v1.01 (Build 20190301)

* NEW: Export file-by-file

### v1.00 (Build 20190201)

* NEW: First version
